import { Stack } from "expo-router";
import { useAuthState } from "../src/hooks/useAuthState";
import { View, ActivityIndicator, StyleSheet } from "react-native";

export default function RootLayout() {
  const { loading } = useAuthState();

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color="#2563eb" />
      </View>
    );
  }

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="login" />
      <Stack.Screen name="(tabs)" />
    </Stack>
  );
}

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f0f2f5",
  },
});
