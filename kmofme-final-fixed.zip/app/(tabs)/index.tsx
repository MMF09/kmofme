import { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
  ActivityIndicator,
  StatusBar,
  Keyboard,
} from "react-native";
import { ref, push, set, onValue } from "firebase/database";
import { auth, db, logsPath } from "../../src/firebase";
import { KmLog } from "../../src/types";
import { signOut } from "firebase/auth";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function yesterdayStr() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export default function Dashboard() {
  const [date, setDate] = useState(todayStr());
  const [km, setKm] = useState("");
  const [note, setNote] = useState("");
  const [selectedLog, setSelectedLog] = useState<KmLog | null>(null);
  const [allLogs, setAllLogs] = useState<KmLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);

  const userId = auth.currentUser?.uid;

  useEffect(() => {
    if (!userId) return;
    const logsRef = ref(db, logsPath(userId));
    const unsubscribe = onValue(logsRef, (snap) => {
      const data = snap.val();
      if (data) {
        const list = Object.entries(data).map(([id, v]) => ({
          ...(v as KmLog),
          id,
        }));
        list.sort((a, b) => b.date.localeCompare(a.date));
        setAllLogs(list);
      } else {
        setAllLogs([]);
      }
      setFetching(false);
    });
    return () => unsubscribe();
  }, [userId]);

  useEffect(() => {
    const found = allLogs.find((l) => l.date === date) || null;
    setSelectedLog(found);
    if (found) {
      setKm(String(found.km));
      setNote(found.note || "");
    } else {
      setKm("");
      setNote("");
    }
  }, [date, allLogs]);

  const handleSave = async () => {
    if (!userId) return;
    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      Alert.alert("Lỗi", "Ngày không hợp lệ (YYYY-MM-DD)");
      return;
    }
    const numKm = parseFloat(km.replace(",", "."));
    if (isNaN(numKm) || numKm < 0) {
      Alert.alert("Lỗi", "Số km không hợp lệ");
      return;
    }
    Keyboard.dismiss();
    setLoading(true);
    try {
      const payload: KmLog = {
        date,
        km: numKm,
        note: note.trim() || null,
        createdAt: Date.now(),
        userId,
      };
      if (selectedLog?.id) {
        await set(ref(db, `${logsPath(userId)}/${selectedLog.id}`), {
          ...payload,
          id: selectedLog.id,
        });
      } else {
        const newRef = push(ref(db, logsPath(userId)));
        await set(newRef, { ...payload, id: newRef.key });
      }
      Alert.alert("Thành công", selectedLog ? "Đã cập nhật số km" : "Đã lưu số km");
    } catch (err: any) {
      Alert.alert("Lỗi", err.message || "Không lưu được");
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    Alert.alert("Đăng xuất", "Bạn có chắc muốn đăng xuất?", [
      { text: "Huỷ", style: "cancel" },
      {
        text: "Đăng xuất",
        style: "destructive",
        onPress: async () => {
          await signOut(auth);
          router.replace("/login");
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={styles.safe} edges={["bottom"]}>
      <StatusBar barStyle="light-content" backgroundColor="#1e293b" />
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
      >
        {/* Quick date chips */}
        <View style={styles.chips}>
          <TouchableOpacity
            style={[styles.chip, date === todayStr() && styles.chipActive]}
            onPress={() => setDate(todayStr())}
          >
            <Text style={[styles.chipText, date === todayStr() && styles.chipTextActive]}>
              Hôm nay
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.chip, date === yesterdayStr() && styles.chipActive]}
            onPress={() => setDate(yesterdayStr())}
          >
            <Text style={[styles.chipText, date === yesterdayStr() && styles.chipTextActive]}>
              Hôm qua
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.card}>
          <Text style={styles.label}>Ngày (YYYY-MM-DD)</Text>
          <TextInput
            style={styles.input}
            value={date}
            onChangeText={setDate}
            placeholder="2026-10-07"
            placeholderTextColor="#94a3b8"
            keyboardType="numbers-and-punctuation"
            autoCapitalize="none"
            maxLength={10}
          />

          {fetching ? (
            <ActivityIndicator style={{ marginVertical: 12 }} color="#2563eb" />
          ) : selectedLog ? (
            <View style={styles.infoBox}>
              <Text style={styles.infoLabel}>Đã ghi nhận</Text>
              <Text style={styles.infoKm}>{selectedLog.km} km</Text>
              {selectedLog.note ? (
                <Text style={styles.infoNote}>{selectedLog.note}</Text>
              ) : null}
            </View>
          ) : (
            <View style={styles.emptyInfo}>
              <Text style={styles.emptyInfoText}>Chưa có dữ liệu ngày này</Text>
            </View>
          )}

          <Text style={styles.label}>Số km đi được</Text>
          <TextInput
            style={styles.input}
            placeholder="Ví dụ: 45.5"
            placeholderTextColor="#94a3b8"
            value={km}
            onChangeText={setKm}
            keyboardType="decimal-pad"
          />

          <Text style={styles.label}>Ghi chú (tuỳ chọn)</Text>
          <TextInput
            style={[styles.input, styles.noteInput]}
            placeholder="Ví dụ: Đi làm + về nhà"
            placeholderTextColor="#94a3b8"
            value={note}
            onChangeText={setNote}
            multiline
          />

          <TouchableOpacity
            style={[styles.button, loading && styles.buttonDisabled]}
            onPress={handleSave}
            disabled={loading}
            activeOpacity={0.85}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>
                {selectedLog ? "Cập nhật" : "Lưu số km"}
              </Text>
            )}
          </TouchableOpacity>
        </View>

        <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
          <Text style={styles.logoutText}>Đăng xuất</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: "#f1f5f9",
  },
  container: {
    flex: 1,
  },
  content: {
    padding: 16,
    paddingBottom: 40,
  },
  chips: {
    flexDirection: "row",
    gap: 10,
    marginBottom: 16,
  },
  chip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#e2e8f0",
  },
  chipActive: {
    backgroundColor: "#2563eb",
    borderColor: "#2563eb",
  },
  chipText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#475569",
  },
  chipTextActive: {
    color: "#fff",
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 18,
    padding: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  label: {
    fontSize: 13,
    fontWeight: "600",
    color: "#475569",
    marginBottom: 6,
    marginTop: 4,
  },
  input: {
    backgroundColor: "#f8fafc",
    paddingHorizontal: 14,
    paddingVertical: 13,
    borderRadius: 12,
    fontSize: 16,
    color: "#0f172a",
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#e2e8f0",
  },
  noteInput: {
    minHeight: 70,
    textAlignVertical: "top",
  },
  infoBox: {
    backgroundColor: "#eff6ff",
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#bfdbfe",
  },
  infoLabel: {
    fontSize: 12,
    color: "#3b82f6",
    fontWeight: "600",
    marginBottom: 2,
  },
  infoKm: {
    fontSize: 22,
    fontWeight: "800",
    color: "#1d4ed8",
  },
  infoNote: {
    marginTop: 4,
    fontSize: 13,
    color: "#64748b",
  },
  emptyInfo: {
    backgroundColor: "#f8fafc",
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
    alignItems: "center",
  },
  emptyInfoText: {
    fontSize: 13,
    color: "#94a3b8",
  },
  button: {
    backgroundColor: "#2563eb",
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: "center",
    marginTop: 8,
  },
  buttonDisabled: {
    opacity: 0.7,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 16,
  },
  logoutBtn: {
    marginTop: 28,
    alignItems: "center",
    padding: 12,
  },
  logoutText: {
    color: "#ef4444",
    fontSize: 15,
    fontWeight: "600",
  },
});
