import { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  StatusBar,
} from "react-native";
import { ref, onValue } from "firebase/database";
import { auth, db, logsPath } from "../../src/firebase";
import { KmLog } from "../../src/types";
import { SafeAreaView } from "react-native-safe-area-context";

export default function History() {
  const [allLogs, setAllLogs] = useState<KmLog[]>([]);
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [filtered, setFiltered] = useState<KmLog[]>([]);
  const [loading, setLoading] = useState(true);

  const userId = auth.currentUser?.uid;

  useEffect(() => {
    if (!userId) return;
    const logsRef = ref(db, logsPath(userId));
    const unsubscribe = onValue(logsRef, (snap) => {
      const data = snap.val();
      if (data) {
        const list = Object.entries(data).map(([id, v]) => ({
          ...(v as KmLog),
          id,
        }));
        list.sort((a, b) => b.date.localeCompare(a.date));
        setAllLogs(list);
      } else {
        setAllLogs([]);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [userId]);

  useEffect(() => {
    let list = [...allLogs];
    if (fromDate) list = list.filter((l) => l.date >= fromDate);
    if (toDate) list = list.filter((l) => l.date <= toDate);
    setFiltered(list);
  }, [allLogs, fromDate, toDate]);

  const totalKm = filtered.reduce((sum, l) => sum + (l.km || 0), 0);

  const clearFilter = () => {
    setFromDate("");
    setToDate("");
  };

  const renderItem = ({ item }: { item: KmLog }) => (
    <View style={styles.item}>
      <View style={styles.row}>
        <View>
          <Text style={styles.date}>{item.date}</Text>
          {item.note ? <Text style={styles.note}>{item.note}</Text> : null}
        </View>
        <Text style={styles.km}>{item.km} km</Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe} edges={["bottom"]}>
      <StatusBar barStyle="light-content" backgroundColor="#1e293b" />
      <View style={styles.container}>
        {/* Filter card */}
        <View style={styles.filterCard}>
          <Text style={styles.filterTitle}>Lọc theo khoảng thời gian</Text>
          <View style={styles.filterRow}>
            <View style={styles.filterCol}>
              <Text style={styles.label}>Từ ngày</Text>
              <TextInput
                style={styles.input}
                value={fromDate}
                onChangeText={setFromDate}
                placeholder="YYYY-MM-DD"
                placeholderTextColor="#94a3b8"
                autoCapitalize="none"
                maxLength={10}
              />
            </View>
            <View style={styles.filterCol}>
              <Text style={styles.label}>Đến ngày</Text>
              <TextInput
                style={styles.input}
                value={toDate}
                onChangeText={setToDate}
                placeholder="YYYY-MM-DD"
                placeholderTextColor="#94a3b8"
                autoCapitalize="none"
                maxLength={10}
              />
            </View>
          </View>
          {(fromDate || toDate) && (
            <TouchableOpacity style={styles.clearBtn} onPress={clearFilter}>
              <Text style={styles.clearText}>Xoá bộ lọc</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Total summary */}
        <View style={styles.totalCard}>
          <Text style={styles.totalLabel}>Tổng cộng</Text>
          <Text style={styles.totalValue}>{totalKm.toFixed(1)} km</Text>
          <Text style={styles.totalCount}>
            {filtered.length > 0 ? `${filtered.length} ngày` : "Không có dữ liệu"}
          </Text>
        </View>

        {loading ? (
          <ActivityIndicator style={{ marginTop: 40 }} size="large" color="#2563eb" />
        ) : (
          <FlatList
            data={filtered}
            keyExtractor={(item) => item.id || item.date}
            contentContainerStyle={styles.list}
            renderItem={renderItem}
            ListEmptyComponent={
              <View style={styles.empty}>
                <Text style={styles.emptyIcon}>📋</Text>
                <Text style={styles.emptyTitle}>Chưa có dữ liệu</Text>
                <Text style={styles.emptyDesc}>
                  Hãy ghi nhận số km ở tab Hôm nay
                </Text>
              </View>
            }
          />
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: "#f1f5f9",
  },
  container: {
    flex: 1,
  },
  filterCard: {
    backgroundColor: "#fff",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e2e8f0",
  },
  filterTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#0f172a",
    marginBottom: 12,
  },
  filterRow: {
    flexDirection: "row",
    gap: 12,
  },
  filterCol: {
    flex: 1,
  },
  label: {
    fontSize: 12,
    fontWeight: "600",
    color: "#64748b",
    marginBottom: 4,
  },
  input: {
    backgroundColor: "#f8fafc",
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 10,
    fontSize: 14,
    color: "#0f172a",
    borderWidth: 1,
    borderColor: "#e2e8f0",
  },
  clearBtn: {
    marginTop: 12,
    alignSelf: "flex-start",
  },
  clearText: {
    color: "#ef4444",
    fontSize: 13,
    fontWeight: "600",
  },
  totalCard: {
    backgroundColor: "#2563eb",
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 16,
    padding: 18,
    alignItems: "center",
  },
  totalLabel: {
    color: "#bfdbfe",
    fontSize: 13,
    fontWeight: "600",
  },
  totalValue: {
    color: "#fff",
    fontSize: 32,
    fontWeight: "800",
    marginVertical: 2,
  },
  totalCount: {
    color: "#93c5fd",
    fontSize: 13,
  },
  list: {
    padding: 16,
    paddingBottom: 40,
  },
  item: {
    backgroundColor: "#fff",
    padding: 16,
    borderRadius: 14,
    marginBottom: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  date: {
    fontWeight: "700",
    fontSize: 15,
    color: "#0f172a",
  },
  km: {
    fontSize: 18,
    color: "#2563eb",
    fontWeight: "800",
  },
  note: {
    color: "#64748b",
    marginTop: 3,
    fontSize: 13,
  },
  empty: {
    alignItems: "center",
    marginTop: 48,
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: 12,
  },
  emptyTitle: {
    fontSize: 17,
    fontWeight: "700",
    color: "#475569",
  },
  emptyDesc: {
    fontSize: 14,
    color: "#94a3b8",
    marginTop: 4,
  },
});
