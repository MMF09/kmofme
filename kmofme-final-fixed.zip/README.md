# Hộp Đen KM - Android (React Native + Expo)

Ứng dụng ghi nhận số km đi được mỗi ngày.

## Công nghệ
- React Native + Expo (SDK 51)
- TypeScript + Expo Router
- Firebase Auth + Realtime Database

## Cách chạy Development (khuyến nghị)

```bash
npm install
npx expo start
```
Sau đó nhấn `a` để mở Android emulator, **hoặc**:

1. Chạy `npx expo start` (giữ terminal này chạy)
2. Mở thư mục `android` bằng Android Studio
3. Bấm Run ▶

> **Quan trọng**: Nếu thấy lỗi đỏ "Unable to load script" → nghĩa là Metro chưa chạy. Hãy chạy `npx expo start` trước.

## Build APK Standalone (không cần Metro)

### Cách 1: Dùng script có sẵn (Debug APK có bundle)

```bash
npm install
npx expo prebuild --platform android --clean
npx expo export --platform android
# Copy bundle vào assets (nếu cần)
cd android
./gradlew assembleDebug
```

APK nằm tại: `android/app/build/outputs/apk/debug/app-debug.apk`

### Cách 2: Dùng EAS (dễ nhất, khuyến nghị)

```bash
npm install -g eas-cli
eas login
eas build -p android --profile debug
```

### Cách 3: GitHub Actions
Push code lên GitHub → vào tab Actions → chạy workflow **Build Android Debug APK**.

## Cấu trúc dữ liệu Firebase
```
users/{uid}/logs/{logId}
  - date, km, note, createdAt, userId, id
```

## Lưu ý lỗi "Unable to load script"
Lỗi này xảy ra khi cài APK debug mà không có Metro bundler.
- Development: luôn chạy `npx expo start` song song.
- Production/chia sẻ: dùng EAS Build hoặc assembleRelease.
